﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BarcodeToEPC;

namespace Trent_RFID_Encoder
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {            
            try
            {
                System.Diagnostics.Debug.WriteLine(barcode.Text.Trim().Length);
                string epcNo = BarcodeToEPC.BarcodeToEPC.GetEpcFromBarcode(barcode.Text.Trim());
                epc.Text = epcNo;
            }
            catch(Exception ex)
            {
                System.Diagnostics.Debug.WriteLine(ex.Message);
            }
        }
    }
}
